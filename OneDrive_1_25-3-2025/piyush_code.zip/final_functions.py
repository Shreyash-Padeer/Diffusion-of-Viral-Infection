import networkx
import numpy
import os
import heapq
from tqdm import tqdm
import random


def get_spread(graph, S):

    file1 = open('temp.txt', 'w')
    text_seed = [str(x) + '\n' for x in S]
    file1.writelines(text_seed)
    file1.close()

    output = os.popen(f'./infection {graph} ./temp.txt')
    spread = float(output.read().strip().split('\n')[3].split(' ')[1])

    return spread


def celf_algorithm(graph, nodes, influence_function, k):
    """
    CELF algorithm for selecting k most influential nodes.
    
    Parameters:
    nodes (list): List of candidate nodes.
    influence_function (function): Function that computes influence spread given a set of nodes.
    k (int): Number of nodes to select.
    
    Returns:
    list: Selected k nodes with highest influence.
    """
    # Compute initial influence gains for each node
    queue = []
    for node in tqdm(nodes):
        gain = get_spread(graph, [node])
        heapq.heappush(queue, (-gain, node, 1))  # Use negative gain for max-heap behavior
    
    selected = []
    for _ in range(k):

        if(len(selected) > 0):
            current_spread = get_spread(graph, selected)
        else:
            current_spread = 0
            
        while queue:
            gain, node, stage = heapq.heappop(queue)
            gain = -gain  # Convert back to positive
            
            if stage == len(selected):
                print('Selected:', node)
                selected.append(node)
                break
            
            # Recompute gain
            new_gain = get_spread(graph, selected + [node]) - current_spread
            heapq.heappush(queue, (-new_gain, node, len(selected)))
    
    return selected