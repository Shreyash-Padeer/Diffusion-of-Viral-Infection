import numpy as np
import networkx as nx
from tqdm import tqdm
import pickle


def get_sorted_nodes(DATASET, N):

    dataset = np.loadtxt('./dataset_1.txt')
    n_nodes = int(max(dataset[:, 0].max(), dataset[:, 1].max()) + 1)

    graph = nx.DiGraph()

    for i in tqdm(range(0, dataset.shape[0])):
        if((dataset[i][0] == dataset[i][1])):
            continue
        else:
            graph.add_edge(int(dataset[i][0]), int(dataset[i][1]), weight = float(dataset[i][2]))

    pagerank_outputs = nx.pagerank(graph.reverse(), weight = 'weight', alpha = 0.65, max_iter = 100)

    sorted_pagerank = sorted(pagerank_outputs.items(), key = lambda kv: (kv[1], kv[0]), reverse = True)[:N]

    best_nodes = [x[0] for x in sorted_pagerank]

    return best_nodes