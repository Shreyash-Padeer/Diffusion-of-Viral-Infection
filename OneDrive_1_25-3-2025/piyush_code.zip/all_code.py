import numpy as np
import pagerank
import final_functions



if __name__ == '__main__':

    DATASET_PATH = './dataset_1.txt'

    dataset = np.loadtxt(DATASET_PATH)
    n_nodes = int(max(dataset[:, 0].max(), dataset[:, 1].max()) + 1)

    initial_seeds = pagerank.get_sorted_nodes(DATASET_PATH, N)
    print('Check Nodes:', len(initial_seeds))
    
    final_seeds = final_functions.celf_algorithm(DATASET_PATH, initial_seeds, None, k = 50)

    write_seeds = [str(x) + '\n' for x in final_seeds]
    file2 = open('seed.txt', 'w')
    file2.writelines(write_seeds[:50])
    file2.close()